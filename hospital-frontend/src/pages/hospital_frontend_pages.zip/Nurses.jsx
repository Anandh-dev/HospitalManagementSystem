function Nurses() {
    return (
        <div>
            <h1>Nurses</h1>
            <p>Nurse management will be available here.</p>
        </div>
    );
}

export default Nurses;
