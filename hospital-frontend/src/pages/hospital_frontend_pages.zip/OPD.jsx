function OPD() {
    return (
        <div>
            <h1>OPD</h1>
            <p>Out-Patient Department management will be available here.</p>
        </div>
    );
}

export default OPD;
