function IPD() {
    return (
        <div>
            <h1>IPD</h1>
            <p>In-Patient Department management will be available here.</p>
        </div>
    );
}

export default IPD;
