function Doctors() {
    return (
        <div>
            <h1>Doctors</h1>
            <p>Doctor management will be available here.</p>
        </div>
    );
}

export default Doctors;
