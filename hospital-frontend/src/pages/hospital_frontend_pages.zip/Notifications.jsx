function Notifications() {
    return (
        <div>
            <h1>Notifications</h1>
            <p>WhatsApp and SMS notification management will be available here.</p>
        </div>
    );
}

export default Notifications;
