function Patients() {
    return (
        <div>
            <h1>Patients</h1>
            <p>Patient management will be available here.</p>
        </div>
    );
}

export default Patients;
