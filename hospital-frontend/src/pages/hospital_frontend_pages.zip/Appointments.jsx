function Appointments() {
    return (
        <div>
            <h1>Appointments</h1>
            <p>Appointment management will be available here.</p>
        </div>
    );
}

export default Appointments;
