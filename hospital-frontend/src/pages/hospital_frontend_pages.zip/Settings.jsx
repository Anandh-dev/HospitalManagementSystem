function Settings() {
    return (
        <div>
            <h1>Settings</h1>
            <p>Hospital system settings will be available here.</p>
        </div>
    );
}

export default Settings;
